﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class CpuCooler : Product
    {
        public string coolerType { get; set; }
        public string size { get; set; }
        public string processorBrand { get; set; }
        public string fanSpeed { get; set; }

    }
}
