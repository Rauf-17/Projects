﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class Keyboard : Product
    {
        public string type { get; set; }
        public string keyboardSwitch { get; set; }

        public string formFactor { get; set; }
    }
}
