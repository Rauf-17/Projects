﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class Motherboard : Product
    {
        public string formFactor { get; set; }
        public string pin { get; set; }
    }
}
