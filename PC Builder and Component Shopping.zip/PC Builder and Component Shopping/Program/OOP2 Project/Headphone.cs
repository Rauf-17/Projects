﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class Headphone : Product
    {
        public string type { get; set; }
        public string portType { get; set; }
        public string sensitivity { get; set; }

    }
}
