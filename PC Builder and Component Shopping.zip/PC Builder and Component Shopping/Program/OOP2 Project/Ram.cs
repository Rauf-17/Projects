﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class Ram : Product
    {
        public string generation { get; set; }
        public string busSpeed { get; set; }
        public string memory { get; set; }
    }
}
